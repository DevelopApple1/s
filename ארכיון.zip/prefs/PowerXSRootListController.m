#include "PowerXSRootListController.h"
#define UIColorFromRGB(rgbValue) \
	[UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
	 green:((float)((rgbValue & 0x00FF00) >>  8))/255.0 \
	 blue:((float)((rgbValue & 0x0000FF) >>  0))/255.0 \
	 alpha:1.0];

@implementation PowerXSRootListController

@synthesize respringButton;

- (instancetype)init {
	self = [super init];

	if (self) {
		HBAppearanceSettings *appearanceSettings = [[HBAppearanceSettings alloc] init];
		appearanceSettings.tintColor = UIColorFromRGB(0xf75454);
		appearanceSettings.tableViewCellSeparatorColor = [UIColor colorWithWhite:0 alpha:0];
		self.hb_appearanceSettings = appearanceSettings;
		self.respringButton = [[UIBarButtonItem alloc] initWithTitle:@"Respring"
		                       style:UIBarButtonItemStylePlain
		                       target:self
		                       action:@selector(respring)];
		self.respringButton.tintColor = UIColorFromRGB(0xf75454);
		self.navigationItem.rightBarButtonItem = self.respringButton;
	}

	return self;
}

-(void)viewDidLoad {
	if(![[NSFileManager defaultManager] fileExistsAtPath:@"/var/lib/dpkg/info/com.yakir.powerxs.list"]) {
		UIAlertController *alertController = [UIAlertController
	        alertControllerWithTitle:@"PowerXS was pirated!"
	        message:@"The build of PowerXS you're using comes from an untrusted source. Pirate repositories can distribute malware and you will get subpar user experience using any tweaks from them.\nRemember: PowerXS is free. Uninstall this build and install the proper version of PowerXS from:\nhttps://repo.conorthedev.com"
	        preferredStyle:UIAlertControllerStyleAlert
	    ];

		[alertController addAction:[UIAlertAction actionWithTitle:@"OK!" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
	        [[UIApplication sharedApplication] openURL:[NSURL URLWithString: @"cydia://url/https://cydia.saurik.com/api/share#?source=https://repo.conorthedev.com"]];
		}]];

		[self presentViewController:alertController animated:YES completion:NULL];
	} else {
		[super viewDidLoad];
	}
}

- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"Root" target:self] retain];
	}
	return _specifiers;
}

- (void)respring {
	NSTask *t = [[[NSTask alloc] init] autorelease];
	[t setLaunchPath:@"/usr/bin/killall"];
	[t setArguments:[NSArray arrayWithObjects:@"backboardd", nil]];
	[t launch];
}


@end

@implementation PowerXSCreditsController

- (instancetype)init {
	self = [super init];

	if (self) {
		HBAppearanceSettings *appearanceSettings = [[HBAppearanceSettings alloc] init];
		appearanceSettings.tintColor = UIColorFromRGB(0xf75454);
		appearanceSettings.tableViewCellSeparatorColor = [UIColor colorWithWhite:0 alpha:0];
		self.hb_appearanceSettings = appearanceSettings;
	}

	return self;
}

- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"Credits" target:self] retain];
	}
	return _specifiers;
}

@end

@implementation PowerXSDefSettingsController

- (instancetype)init {
	self = [super init];

	if (self) {
		HBAppearanceSettings *appearanceSettings = [[HBAppearanceSettings alloc] init];
		appearanceSettings.tintColor = UIColorFromRGB(0xf75454);
		appearanceSettings.tableViewCellSeparatorColor = [UIColor colorWithWhite:0 alpha:0];
		self.hb_appearanceSettings = appearanceSettings;
	}

	return self;
}

- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"DefaultSettings" target:self] retain];
	}
	return _specifiers;
}

@end

@implementation PowerXSModernSettingsController

- (instancetype)init {
	self = [super init];

	if (self) {
		HBAppearanceSettings *appearanceSettings = [[HBAppearanceSettings alloc] init];
		appearanceSettings.tintColor = UIColorFromRGB(0xf75454);
		appearanceSettings.tableViewCellSeparatorColor = [UIColor colorWithWhite:0 alpha:0];
		self.hb_appearanceSettings = appearanceSettings;
	}

	return self;
}

- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"ModernSettings" target:self] retain];
	}
	return _specifiers;
}

@end

@implementation PowerXSCustomSettingsController

- (instancetype)init {
	self = [super init];

	if (self) {
		HBAppearanceSettings *appearanceSettings = [[HBAppearanceSettings alloc] init];
		appearanceSettings.tintColor = UIColorFromRGB(0xf75454);
		appearanceSettings.tableViewCellSeparatorColor = [UIColor colorWithWhite:0 alpha:0];
		self.hb_appearanceSettings = appearanceSettings;
	}

	return self;
}

- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"CustomSettings" target:self] retain];
	}
	return _specifiers;
}

@end
@implementation PowerXSModernGXSettingsController

- (instancetype)init {
    self = [super init];
    
    if (self) {
        HBAppearanceSettings *appearanceSettings = [[HBAppearanceSettings alloc] init];
        appearanceSettings.tintColor = UIColorFromRGB(0xf75454);
        appearanceSettings.tableViewCellSeparatorColor = [UIColor colorWithWhite:0 alpha:0];
        self.hb_appearanceSettings = appearanceSettings;
    }
    
    return self;
}

- (id)specifiers {
    if(_specifiers == nil) {
        _specifiers = [[self loadSpecifiersFromPlistName:@"ModernGXSettings" target:self] retain];
    }
    return _specifiers;
}

@end
